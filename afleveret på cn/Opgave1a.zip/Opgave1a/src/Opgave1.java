
public class Opgave1 {

	public static void main(String[] args) {
		String text="Use \"\\\\\" to obtain a �backslash� character.";
		System.out.println (text);
		System.out.println ("Remember:");
		System.out.println (text);
	}
}
