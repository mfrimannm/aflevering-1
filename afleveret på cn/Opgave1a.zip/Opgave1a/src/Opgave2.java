
public class Opgave2 {
public static void main(String[] args) {
double x= 7.2;
System.out.println(1 + 3 + x + x + x + x + x + 5 / 4 * 2);
	}
}